import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreMapsRoutingModule } from './core-maps-routing.module';

@NgModule({
  imports: [
    CommonModule,
    CoreMapsRoutingModule
  ],
  declarations: []
})
export class CoreMapsModule { }
