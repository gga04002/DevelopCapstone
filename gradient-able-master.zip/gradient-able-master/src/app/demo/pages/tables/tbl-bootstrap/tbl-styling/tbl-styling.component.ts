import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tbl-styling',
  templateUrl: './tbl-styling.component.html',
  styleUrls: ['./tbl-styling.component.scss']
})
export class TblStylingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
